export const DUMMY_LIKES = [
  {
    benefitCode: 101,
    benefitName: '어르신 기초연금 지원',
    detail: '65세 이상 어르신에게 월 최대 30만원 지원합니다.',
  },
  {
    benefitCode: 102,
    benefitName: '장애인 활동지원 서비스',
    detail: '중증 장애인 대상 활동지원 서비스 제공',
  },
  {
    benefitCode: 103,
    benefitName: '청년 취업 지원 프로그램',
    detail: '만 19~34세 청년 대상 취업 연계 교육 및 상담',
  },
];
