import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './src/screens/chat/HomeScreen';
import ChatScreen from './src/screens/chat/ChatScreen';
import FavoriteListScreen from './src/screens/chat/FavoriteListScreen';
import WelfareDetailScreen from './src/screens/chat/WelfareDetailScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home" // ⭐️ 여기! 앱 시작 시 HomeScreen으로 시작
        screenOptions={{
          headerShown: false, // 필요에 따라 true로 설정
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Chat" component={ChatScreen} />
        <Stack.Screen name="FavoriteList" component={FavoriteListScreen} />
        <Stack.Screen name="WelfareDetail" component={WelfareDetailScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
