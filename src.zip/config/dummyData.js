// src/config/dummyData.js
export const welfareData = [
  // 임산부 복지 • 경제
  {
    id: 'prego-econ-1',
    ageGroup: '임산부 복지',
    category: '경제',
    title: '임산부 교통비 지원',
    desc: '버스·지하철 요금 면제',
    detail:
      '임신부를 대상으로 대중교통 요금을 전액 또는 일부 면제해 드립니다. 신청방법: ○○○ 기관 방문...',
  },
  {
    id: 'prego-econ-2',
    ageGroup: '임산부 복지',
    category: '경제',
    title: '산후조리비 지원',
    desc: '출산 후 산후조리비 최대 100만원 지원',
    detail:
      '출산 직후 ~ 6개월 이내에 발생한 산후조리비용을 최대 100만원까지 지원해 드립니다...',
  },
  // 임산부 복지 • 의료
  {
    id: 'prego-med-1',
    ageGroup: '임산부 복지',
    category: '의료',
    title: '임신부 건강검진 지원',
    desc: '임신 중 필수 건강검진 4회 지원',
    detail:
      '국가에서 지원하는 임신 주기별 4회의 건강검진 비용을 전액 지원해 드립니다...',
  },
  // (여기에 필요만큼 더미 아이템 추가)
];
