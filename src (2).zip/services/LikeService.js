// src/services/LikeService.js
let favorites = [];

export function getFavorites() {
  return [...favorites];
}

export function addFavorite(item) {
  if (!favorites.find((f) => f.id === item.id)) {
    favorites.push(item);
  }
}

export function removeFavorite(itemId) {
  favorites = favorites.filter((f) => f.id !== itemId);
}
