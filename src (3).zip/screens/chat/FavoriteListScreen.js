import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useLike } from '../../context/LikeContext';

export default function FavoriteListScreen() {
  const { likedItems, toggleLike } = useLike();
  const navigation = useNavigation();

  const handleDelete = (item) => {
    Alert.alert('삭제', `"${item.title}" 항목을 삭제할까요?`, [
      { text: '취소', style: 'cancel' },
      { text: '삭제', onPress: () => toggleLike(item) },
    ]);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={likedItems}
        keyExtractor={(item) => item.id.toString()}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => navigation.navigate('WelfareDetail', { item })}
            onLongPress={() => handleDelete(item)}
            style={styles.card}
          >
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.desc}>{item.content}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.empty}>좋아요한 항목이 없습니다.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#CFF1F5', padding: 16 },
  card: { backgroundColor: '#fff', padding: 15, borderRadius: 8 },
  title: { fontWeight: 'bold', fontSize: 16, marginBottom: 5 },
  desc: { color: '#555' },
  separator: { height: 1, backgroundColor: '#000', marginVertical: 10 },
  empty: { textAlign: 'center', marginTop: 50, color: '#777' },
});
