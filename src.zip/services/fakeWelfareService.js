import { welfareData } from '../config/dummyData';

// 선택한 연령대·카테고리에 해당하는 리스트 반환
export function getWelfareByAgeAndCategory(age, category) {
  if (
    welfareData[age] &&
    welfareData[age][category] &&
    Array.isArray(welfareData[age][category])
  ) {
    return welfareData[age][category];
  }
  return [];
}

// 키워드 검색 (제목 포함)
export function searchWelfareByKeyword(keyword) {
  const lower = keyword.toLowerCase();
  const all = Object.values(welfareData).flatMap(catMap =>
    Object.values(catMap).flat()
  );
  return all.filter(item =>
    item.title.toLowerCase().includes(lower)
  );
}
