// src/screens/chat/WelfareListScreen.js
import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { welfareData } from '../../config/dummyData';
import { useRoute, useNavigation } from '@react-navigation/native';

export default function WelfareListScreen() {
  const { ageGroup, category } = useRoute().params;
  const navigation = useNavigation();

  const list = welfareData.filter(
    (item) => item.ageGroup === ageGroup && item.category === category
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={list}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate('WelfareDetail', { item })}
          >
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.desc}>{item.desc}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={{ textAlign: 'center', marginTop: 20 }}>해당 항목이 없습니다.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#C9EAEC', padding: 12 },
  card: {
    backgroundColor: '#55B7B5',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  title: { fontSize: 16, fontWeight: 'bold', color: '#fff' },
  desc: { fontSize: 14, color: '#fff', marginTop: 4 },
});
