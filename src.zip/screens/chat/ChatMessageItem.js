import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { addFavorite, removeFavorite, getFavorites } from '../../services/LikeService';

export default function ChatMessageItem({ message }) {
  // message.type: 'bot' | 'user' | 'list-item' | 'detail'
  if (message.type === 'user') {
    return (
      <View style={styles.userBubble}>
        <Text style={styles.userText}>{message.text}</Text>
      </View>
    );
  }

  if (message.type === 'list-item') {
    // 복지 목록 항목
    return (
      <TouchableOpacity style={styles.listItem} onPress={message.onPress}>
        <View>
          <Text style={styles.listTitle}>{message.title}</Text>
          <Text style={styles.listDesc}>{message.desc}</Text>
        </View>
      </TouchableOpacity>
    );
  }

  if (message.type === 'detail') {
    const favs = getFavorites();
    const liked = favs.some(f=>f.id===message.item.id);
    const toggle = () => liked ? removeFavorite(message.item.id) : addFavorite(message.item);
    return (
      <View style={styles.detailCard}>
        <View style={styles.detailHeader}>
          <Text style={styles.detailTitle}>{message.item.title}</Text>
          <TouchableOpacity onPress={toggle}>
            <Text style={styles.heart}>{liked ? '❤️' : '🤍'}</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.detailText}>{message.item.detail}</Text>
      </View>
    );
  }

  // 기본 봇 메시지
  return (
    <View style={styles.botBubble}>
      <Text style={styles.botText}>{message.text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  userBubble:{ alignSelf:'flex-end', backgroundColor:'#fff', padding:8, borderRadius:8, marginVertical:4 },
  userText:{ color:'#000' },
  botBubble:{ alignSelf:'flex-start', backgroundColor:'#55B7B5', padding:8, borderRadius:8, marginVertical:4 },
  botText:{ color:'#000' },
  listItem:{ backgroundColor:'#55B7B5', padding:12, borderRadius:12, marginVertical:4 },
  listTitle:{ fontWeight:'bold', color:'#fff' },
  listDesc:{ color:'#fff', marginTop:4 },
  detailCard:{ backgroundColor:'#55B7B5', padding:12, borderRadius:12, marginVertical:4 },
  detailHeader:{ flexDirection:'row', justifyContent:'space-between', alignItems:'center' },
  detailTitle:{ fontWeight:'bold', color:'#000', flex:1 },
  heart:{ fontSize:20 },
  detailText:{ color:'#000', marginTop:8 },
});
