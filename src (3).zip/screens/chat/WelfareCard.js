import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useLike } from '../../context/LikeContext';
import { FontAwesome } from '@expo/vector-icons';

export default function WelfareCard({ item }) {
  const { likedItems, toggleLike } = useLike();
  const isLiked = likedItems.some(i => i.id === item.id);

  return (
    <View style={styles.card}>
      <View style={styles.textBox}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.content}>{item.content}</Text>
      </View>
      <TouchableOpacity onPress={() => toggleLike(item)} style={styles.iconWrap}>
        <FontAwesome
          name={isLiked ? 'heart' : 'heart-o'}
          size={24}
          color={isLiked ? '#FF3366' : '#ccc'}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 2,
  },
  textBox: {
    flex: 1,
    paddingRight: 10,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 6,
    color: '#333',
  },
  content: {
    fontSize: 14,
    color: '#555',
  },
  iconWrap: {
    padding: 5,
  },
});
