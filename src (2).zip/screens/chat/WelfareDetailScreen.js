// src/screens/chat/WelfareDetailScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { addFavorite, removeFavorite, getFavorites } from '../../services/LikeService';
import { useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';

export default function WelfareDetailScreen() {
  const { item } = useRoute().params;
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    const favs = getFavorites();
    setLiked(!!favs.find((f) => f.id === item.id));
  }, []);

  const toggleLike = () => {
    if (liked) {
      removeFavorite(item.id);
    } else {
      addFavorite(item);
    }
    setLiked(!liked);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{item.title}</Text>
        <TouchableOpacity onPress={toggleLike}>
          <Ionicons name={liked ? 'heart' : 'heart-outline'} size={28} color={liked ? 'red' : 'white'} />
        </TouchableOpacity>
      </View>
      <Text style={styles.detail}>{item.detail}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#C9EAEC', padding: 16 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  title: { fontSize: 18, fontWeight: 'bold', color: '#000' },
  detail: { fontSize: 16, color: '#000', marginTop: 8 },
});
