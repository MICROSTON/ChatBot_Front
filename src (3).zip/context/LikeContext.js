import React, { createContext, useContext, useState } from 'react';

const LikeContext = createContext();

export const LikeProvider = ({ children }) => {
  const [likedItems, setLikedItems] = useState([]);

  const toggleLike = (item) => {
    const exists = likedItems.some(i => i.id === item.id);
    if (exists) {
      setLikedItems(likedItems.filter(i => i.id !== item.id));
    } else {
      setLikedItems([...likedItems, item]);
    }
  };

  return (
    <LikeContext.Provider value={{ likedItems, toggleLike }}>
      {children}
    </LikeContext.Provider>
  );
};

export const useLike = () => useContext(LikeContext);
