export const DUMMY_MESSAGES = [
  {
    id: '1',
    sender: 'bot',
    message: '안녕하세요! 어떤 복지가 필요하신가요?',
    timestamp: '2025-07-31 15:00',
  },
  {
    id: '2',
    sender: 'user',
    message: '청년 복지 추천해주세요!',
    timestamp: '2025-07-31 15:01',
  },
];
