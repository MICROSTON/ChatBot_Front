// chatAPI.js
export const getWelfareDummyData = (target, category) => {
  const dummyDB = {
    '임산부': {
      '경제': [
        {
          id: 'p1',
          content: '임산부 교통비 지원',
          detail: '임산부를 대상으로 한 교통비 지원 사업입니다. 최대 70,000원 지원.',
        },
        {
          id: 'p2',
          content: '임산부 출산장려금',
          detail: '출산 시 100만원 상당의 출산장려금 지급',
        },
      ],
      '의료': [
        {
          id: 'm1',
          content: '산전 검진 지원',
          detail: '임산부의 산전 검진에 대한 무료 지원이 제공됩니다.',
        }
      ]
    }
  };

  return dummyDB[target]?.[category] || [];
};
