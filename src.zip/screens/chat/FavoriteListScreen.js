// src/screens/chat/FavoriteListScreen.js
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Alert
} from 'react-native';
import { getFavorites, removeFavorite } from '../../services/LikeService';
import { useNavigation } from '@react-navigation/native';

export default function FavoriteListScreen() {
  const navigation = useNavigation();
  const [list, setList] = useState([]);

  useEffect(() => {
    const subs = navigation.addListener('focus', () => {
      setList(getFavorites());
    });
    return subs;
  }, [navigation]);

  const confirmDelete = (id) => {
    Alert.alert('삭제', '정말 삭제하시겠습니까?', [
      { text: '취소' },
      { text: '삭제', onPress: () => {
        removeFavorite(id);
        setList(getFavorites());
      } },
    ]);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={list}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <TouchableOpacity
              style={styles.info}
              onPress={() => navigation.navigate('WelfareDetail', { item })}
            >
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.desc}>{item.desc}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => confirmDelete(item.id)}>
              <Text style={styles.delete}>삭제</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={<Text style={{ textAlign: 'center', marginTop: 20 }}>좋아요한 항목이 없습니다.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 12 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomColor: '#eee',
    borderBottomWidth: 1
  },
  info: { flex: 1 },
  title: { fontSize: 16, fontWeight: 'bold' },
  desc: { fontSize: 14, color: '#555', marginTop: 4 },
  delete: { color: 'red', padding: 8 },
});
