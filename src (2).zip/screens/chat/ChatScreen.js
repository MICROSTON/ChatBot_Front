// src/screens/chat/ChatScreen.js
import React, { useEffect, useState } from 'react';
import {
  View,
  StyleSheet,
  ImageBackground,
  ScrollView,
  Image,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Text
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

import AgeButtons from './AgeButtons';
import WelfareButtons from './WelfareButtons';

const BG = require('../../../assets/images/background.png');
const MASCOT = require('../../../assets/images/mascot.png');

export default function ChatScreen() {
  const navigation = useNavigation();
  const [selectedAgeGroup, setSelectedAgeGroup] = useState(null);
  const [showCategoryButtons, setShowCategoryButtons] = useState(false);

  // 초기 챗봇 인사 메시지만 화면 상단에 두고, 실제 대화는 하지 않고
  // 화면 중앙마스코트 하단부에 버튼만 노출하는 구조로 바꿨습니다.
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.select({ ios: 'padding', android: undefined })}
      keyboardVerticalOffset={0}
    >
      <ImageBackground source={BG} style={styles.backgroundImage}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <View style={styles.avatarWrapper}>
            <Image source={MASCOT} style={styles.avatarLarge} />
          </View>
          <View style={{ paddingHorizontal: 12, marginBottom: 20 }}>
            <View style={styles.botBubble}>
              <Text style={styles.botText}>안녕하세요. 신한봇입니다!</Text>
            </View>
            <View style={styles.botBubble}>
              <Text style={styles.botText}>
                연령대나 상황에 따라 받을 수 있는 맞춤형 복지 혜택을 알려드릴게요.{'\n'}
                먼저, 어떤 대상에 해당하시는지 선택해주세요.
              </Text>
            </View>
          </View>

          {/* 1️⃣ 연령대 버튼 (항상 노출) */}
          <AgeButtons onSelect={(age) => {
            setSelectedAgeGroup(age);
            setShowCategoryButtons(true);
          }} />

          {/* 2️⃣ 복지 카테고리 버튼 (연령대 선택 시) */}
          {showCategoryButtons && (
            <WelfareButtons onSelect={(category) => {
              navigation.navigate('WelfareList', { ageGroup: selectedAgeGroup, category });
            }} />
          )}
        </ScrollView>
      </ImageBackground>

      {/* 오른쪽 상단에 즐겨찾기(좋아요) 리스트로 이동 */}
      <TouchableOpacity
        style={styles.favButton}
        onPress={() => navigation.navigate('Favorites')}
      >
        <Text style={{ color: '#fff' }}>💖</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#C9EAEC' },
  backgroundImage: { flex: 1, resizeMode: 'cover' },
  scrollContent: { paddingTop: 20, paddingBottom: 100 },
  avatarWrapper: { alignItems: 'center', marginBottom: 12 },
  avatarLarge: { width: 120, height: 120, borderRadius: 60, borderWidth: 4, borderColor: '#fff' },
  botBubble: {
    backgroundColor: '#55B7B5',
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  botText: { color: '#000', fontSize: 14 },
  favButton: {
    position: 'absolute',
    top: Platform.OS==='ios'?50:20,
    right: 20,
    backgroundColor: '#55B7B5',
    padding: 8,
    borderRadius: 16,
  },
});
