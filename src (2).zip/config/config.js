export const CONFIG = {
  useDummyData: true,
  apiUrl: 'http://localhost:8080',
  timeout: 10000,
};
