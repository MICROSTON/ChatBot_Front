import React, { useState } from 'react';
import { View, StyleSheet, Image, ScrollView, Text } from 'react-native';
import AgeButtons from './AgeButtons';
import WelfareButtons from './WelfareButtons';
import { dummyData } from '../../config/dummyData';
import WelfareCard from './WelfareCard';

export default function ChatScreen() {
  const [selectedAgeGroup, setSelectedAgeGroup] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);

  const filteredData = (dummyData || []).filter(item =>
    item.ageGroup === selectedAgeGroup && item.category === selectedCategory
  );

  return (
    <View style={styles.container}>
      <View style={styles.chatHeader}>
        <Image source={require('../../../assets/images/mascot.png')} style={styles.mascot} />
        <Text style={styles.botText}>안녕하세요. 신한봇입니다!</Text>
        <Text style={styles.subText}>
          연령대나 상황에 따라 받을 수 있는 맞춤형 복지 혜택을 알려드릴게요. 먼저, 어떤 대상에 해당하시는지 선택해주세요.
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollArea}>
        <AgeButtons onSelectAgeGroup={setSelectedAgeGroup} />
        {selectedAgeGroup && <WelfareButtons onSelectCategory={setSelectedCategory} />}
        {selectedAgeGroup && selectedCategory && (
          <View style={styles.resultArea}>
            {filteredData.map((item) => (
              <WelfareCard key={item.id} item={item} />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#CFF1F5' },
  chatHeader: { padding: 20, alignItems: 'center' },
  mascot: { width: 80, height: 80, marginBottom: 10 },
  botText: { fontSize: 18, fontWeight: 'bold', marginBottom: 5 },
  subText: { fontSize: 14, textAlign: 'center' },
  scrollArea: { paddingHorizontal: 20 },
  resultArea: { marginTop: 20 },
});
